# Takara.ai Branding Pack

Welcome to the [Takara.ai](https://takara.ai) Branding Pack! This pack contains all the necessary assets and guidelines for using the Takara.ai logo and brand elements across various platforms and media.

## Contents

### 1. Logo Files

The Takara.ai logo is an origami red crane, symbolizing peace, longevity, and innovation. We have provided the logo in different color variations and formats to suit various use cases.

#### 1.1 Black Crane

- **black_crane_red_background.jpg**: JPEG file of the black crane logo with a red background.
- **black_crane_transparent_background.png**: PNG file of the black crane logo with a transparent background.
- **black_crane_vector.svg**: SVG file of the black crane logo, suitable for scalable and high-quality use.
- **black_crane_white_background.jpg**: JPEG file of the black crane logo with a white background.

#### 1.2 Red Crane

- **red_crane_black_background.jpg**: JPEG file of the red crane logo with a black background.
- **red_crane_transparent_background.png**: PNG file of the red crane logo with a transparent background.
- **red_crane_vector.svg**: SVG file of the red crane logo, suitable for scalable and high-quality use.
- **red_crane_white_background.jpg**: JPEG file of the red crane logo with a white background.

#### 1.3 White Crane

- **white_crane_black_background.jpg**: JPEG file of the white crane logo with a black background.
- **white_crane_red_background.jpg**: JPEG file of the white crane logo with a red background.
- **white_crane_transparent_background.png**: PNG file of the white crane logo with a transparent background.
- **white_crane_vector.svg**: SVG file of the white crane logo, suitable for scalable and high-quality use.

### 2. Brand Guidelines

- **takara.ai Brand Guide.pdf**: A comprehensive guide on how to use the Takara.ai logo, color palette, typography, and other branding elements. Please refer to this document to ensure consistent and proper use of our brand assets.

## How to Use

- **Vector Files (.svg)**: Ideal for high-resolution prints, large-scale graphics, or any situation requiring resizing without quality loss.
- **JPEG Files (.jpg)**: Best for use in digital and print media where transparency is not needed.
- **PNG Files (.png)**: Recommended for web use, especially when you need a transparent background.

## Licensing and Usage

By using these assets, you agree to adhere to the guidelines outlined in the **takara.ai Brand Guide.pdf**. The assets provided here are for use by authorized partners and representatives of Takara.ai.

## Contact Us

If you have any questions or require additional resources, please contact our branding team at [press@takara.ai](mailto:press@takara.ai).

## Share Your Work

We’d love to see how you use our brand assets! If you create something using our logo, please share it with us on LinkedIn by tagging `@takara.ai`. We can't wait to see your beautiful creations!
